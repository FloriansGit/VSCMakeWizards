// $safeprojectname$.cpp

#include "$safeprojectname$.h"

$safeprojectname$::$safeprojectname$()
{

}

$safeprojectname$::~$safeprojectname$()
{

}
