// $safeprojectname$.h

class $safeprojectname$
{
public:
    $safeprojectname$();
    virtual ~$safeprojectname$();
};
